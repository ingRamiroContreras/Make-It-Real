puts "llego tarde"
name = gets.chomp.upcase

#if(name.upcase == "ALEJANRO")
#    puts "angie lo sabia"
#else
#    puts "el no llego tarde"
#end


#ternario
puts name == "ALEJANDRO" ? "angie lo sabia" : " el no llego tarde"