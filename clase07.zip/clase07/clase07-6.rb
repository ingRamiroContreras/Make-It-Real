puts "ingrsa numero de 1 a 5"
num = gets.chomp.to_i

puts num <= 5 && num >= 1 ? "es el correcto" : "intenta de nuevo"