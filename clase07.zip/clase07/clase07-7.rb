
5.times do |i|
    puts i == 4 ? ("*" * i ) : "*" + (" " * i) + "*"
end