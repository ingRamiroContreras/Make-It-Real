class Language < ApplicationRecord
  has_many :votes
end
