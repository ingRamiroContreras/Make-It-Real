class LanguagesController < ApplicationController
end
